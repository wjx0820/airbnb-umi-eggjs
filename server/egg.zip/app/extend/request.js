module.exports = {
  get token() {
    return this.get("token");
  },
};
