module.exports = {
  set token(token) {
    this.set("token", token);
  },
};
